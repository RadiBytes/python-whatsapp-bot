class Dispatcher:
    def __init__(self,bot) -> None:
        pass